module dual_fsm_top (
    input clk,
    input nrst,
    input start,
    input work_done,
    output mode_led,
    output act_out
);

    // 内部连线
    wire internal_req;
    wire internal_ack;

    // 实例化老板 (SM1)
    SM1 u_top (
        .clk        (clk),
        .nrst       (~nrst),  // 🔥 重点修改：加波浪号取反！将外部低有效转换为内部高有效
        .start      (start),
        .ack        (internal_ack), 
        .req        (internal_req), 
        .mode_led   (mode_led)
    );

    // 实例化员工 (FSM)
    FSM u_c3 (
        .clk        (clk),
        .nrst       (~nrst),  // 🔥 重点修改：加波浪号取反！将外部低有效转换为内部高有效
        .req        (internal_req), 
        .work_done  (work_done),
        .ack        (internal_ack), 
        .act_out    (act_out)
    );

endmodule