`timescale 1ns / 1ps 

module dual_fsm_tb();

    // 模拟输入信号
    reg clk;
    reg nrst;
    reg start;
    reg work_done;
    
    // 模拟输出信号
    wire mode_led;
    wire act_out;

    // 把我们做好的顶层大盒子放进来测试
    dual_fsm_top dut (
        .clk(clk),
        .nrst(nrst),
        .start(start),
        .work_done(work_done),
        .mode_led(mode_led),
        .act_out(act_out)
    );

    // 产生 50MHz 时钟 (每10ns翻转一次)
    initial begin
        clk = 0;
        forever #10 clk = ~clk;
    end

    // 模拟人去按按键的流程
    initial begin
        // 1. 初始状态：复位按住
        nrst = 0;
        start = 0;
        work_done = 0;
        
        // 2. 松开复位，系统开始待命
        #50;
        nrst = 1;
        #50;

        // 3. 按下 start 键（顶层收到信号开始干活）
        start = 1;
        #20; 
        start = 0; // 松开按键

        // 此时系统内部 req 应该会变高，底层开始工作 (act_out变高)
        // 假装活很多，让它干一会儿...
        #200;

        // 4. 模拟外部硬件发来信号：活干完了！
        work_done = 1;
        #20;
        work_done = 0; 

        // 此时底层会发出 ack，顶层收到后撤销 req，全部回到初始状态
        
        // 再看一会儿波形，然后停止仿真
        #200;
        $stop;
    end

endmodule