/* Quartus Prime Version 24.1std.0 Build 1077 03/04/2025 SC Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE15F17) Path("D:/Quartur/Code/artibuter/output_files/") File("uart_system_top.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
