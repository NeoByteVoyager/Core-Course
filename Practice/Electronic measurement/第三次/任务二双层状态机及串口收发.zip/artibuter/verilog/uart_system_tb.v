`timescale 1ns / 1ps

module uart_system_tb();

    reg clk;
    reg nrst;
    reg rx;
    reg tx_req;
    reg [7:0] tx_data_ext;

    wire tx;
    wire rx_ready;
    wire tx_busy;
    wire [1:0] arb_state;

    // 实例化顶层系统盒
    uart_system_top dut (
        .clk(clk),
        .nrst(nrst),
        .rx(rx),
        .tx_req(tx_req),
        .tx_data_ext(tx_data_ext),
        .tx(tx),
        .rx_ready(rx_ready),
        .tx_busy(tx_busy),
        .arb_state(arb_state)
    );

    // 50MHz 时钟源
    initial clk = 0;
    always #10 clk = ~clk;

    // 模拟外设串行发送数据任务
    task send_rx_byte;
        input [7:0] data;
        integer i;
        begin
            rx = 0; #(434 * 20); // 起始位
            for (i = 0; i < 8; i = i + 1) begin
                rx = data[i];
                #(434 * 20); // 数据位
            end
            rx = 1; #(434 * 20); // 停止位
        end
    endtask

    initial begin
        // 初始化状态
        nrst = 0;
        rx = 1;
        tx_req = 0;
        tx_data_ext = 8'h00;
        #100;
        nrst = 1;
        #500;

        // 场景一：无冲突状态下，纯外部发起的主动发送请求 (发送0x3A)
        tx_data_ext = 8'h3A;
        tx_req = 1; #20; tx_req = 0; // 发送1个周期脉冲
        
        // 等待发送驱动模块完成发送
        @(negedge tx_busy);
        #2000;

        // 场景二：【🔥制造修罗场冲突】
        // 在接收 0x8F 数据帧的同时，在即将接收完成、准备产生 rx_ready 的前夕，突然外部发起 tx_req 发送 0xCC 请求。
        // 验证仲裁状态机是否能顶住冲突，优先执行 rx 数据的自动转发。
        
        tx_data_ext = 8'hCC; // 外部想强行插队发送 0xCC
        
        // 开启并行线程：一边在rx线上接收 0x8F
        fork
            send_rx_byte(8'h8F); 
            begin
                // 故意计算时间：在接收到第8个数据位中间（第9个码元周期），突然拉高 tx_req 造成撞车
                #(434 * 20 * 9); 
                tx_req = 1;
                #20;
                tx_req = 0;
            end
        join

        // 冲突发生后，静静观察波形行为是否为：先转发出rx收到的 8'h8F，发送完后立刻响应执行 8'hCC
        #200000;
        $stop;
    end

endmodule
