module Uart_rx(
    input wire clk,             // 系统时钟 50MHz
    input wire nrst,            // 外部复位，低电平有效
    input wire rx,              // UART 串行接收线
    output reg [7:0] SBUF_rx,   // 8位单字节接收缓冲区
    output reg rx_ready         // 数据接收完成就绪脉冲 (高有效，持续1个时钟周期)
);

    parameter BPS_CNT  = 16'd434; 
    parameter BPS_HALF = 16'd217; 

    reg rx_reg1, rx_reg2, rx_reg3;
    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            rx_reg1 <= 1'b1; 
            rx_reg2 <= 1'b1; 
            rx_reg3 <= 1'b1; 
        end else begin
            rx_reg1 <= rx;       
            rx_reg2 <= rx_reg1;  
            rx_reg3 <= rx_reg2;  
        end
    end
    
    wire rx_fall = rx_reg3 & ~rx_reg2; 

    reg rx_en; 
    always @(posedge clk or negedge nrst) begin
        if (!nrst) 
            rx_en <= 1'b0;
        else if (rx_fall) 
            rx_en <= 1'b1;     
        else if (rx_ready) 
            rx_en <= 1'b0;     
    end

    reg [15:0] baud_cnt;
    always @(posedge clk or negedge nrst) begin
        if (!nrst) 
            baud_cnt <= 16'd0;
        else if (rx_en) begin
            if (baud_cnt == BPS_CNT - 1) 
                baud_cnt <= 16'd0; 
            else 
                baud_cnt <= baud_cnt + 1'b1;
        end else 
            baud_cnt <= 16'd0;
    end

    reg [3:0] bit_cnt; 
    reg [7:0] rx_data; 

    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            bit_cnt <= 4'd0;
            rx_data <= 8'd0;
            rx_ready <= 1'b0;
            SBUF_rx <= 8'd0;
        end else if (rx_en) begin
            if (baud_cnt == BPS_HALF) begin 
                case (bit_cnt)
                    4'd0: bit_cnt <= bit_cnt + 1'b1; 
                    4'd1: begin rx_data[0] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd2: begin rx_data[1] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd3: begin rx_data[2] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd4: begin rx_data[3] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd5: begin rx_data[4] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd6: begin rx_data[5] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd7: begin rx_data[6] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd8: begin rx_data[7] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd9: begin 
                        bit_cnt <= 4'd0;     
                        rx_ready <= 1'b1;    
                        SBUF_rx <= rx_data;  
                    end
                    default: bit_cnt <= 4'd0;
                endcase
            end else begin
                rx_ready <= 1'b0; 
            end
        end else begin
            bit_cnt <= 4'd0;
            rx_ready <= 1'b0;
        end
    end
endmodule
