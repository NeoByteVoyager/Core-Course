module Arbitrator(
    input wire clk,                 // 系统时钟 50MHz
    input wire nrst,                // 外部复位，低电平有效
    input wire rx_ready,            // 串口接收模块接收完成信号
    input wire [7:0] SBUF_rx,       // 串口接收缓冲区数据
    input wire tx_req,              // 外部按键/模块发送数据请求
    input wire [7:0] tx_data_ext,   // 外部请求发送的自定义数据
    input wire tx_busy,             // 串口发送模块忙状态信号
    output reg tx_start,            // 触发串口发送模块启动信号
    output reg [7:0] SBUF_tx,       // 串口发送缓冲区数据
    output reg [1:0] current_state  // 用于仿真观察的仲裁状态指示
);

    // 状态机编码定义
    parameter IDLE       = 2'b00;   // 空闲待命状态
    parameter RX_PRIO    = 2'b01;   // 优先处理接收数据转发
    parameter TX_PRIO    = 2'b10;   // 处理外部发送请求
    parameter WAIT_BUSY  = 2'b11;   // 等待发送完毕状态

    reg [1:0] state, next_state;
    
    // 【🔥核心升级：记忆外挂】
    reg rx_pending;             // 接收挂起标志
    reg [7:0] rx_pending_data;  // 暂存被错过的数据

    // 独立线程：专门负责捕捉在 Busy 期间错过的接收脉冲
    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            rx_pending <= 1'b0;
            rx_pending_data <= 8'd0;
        end else if (rx_ready && state != IDLE) begin
            // 绝杀：如果系统不在空闲状态时收到了数据，立马挂起记在小本子上！
            rx_pending <= 1'b1;
            rx_pending_data <= SBUF_rx;
        end else if (state == RX_PRIO) begin
            // 数据已经被优先处理了，擦除小本子
            rx_pending <= 1'b0;
        end
    end

    // 同步时序逻辑：状态切换
    always @(posedge clk or negedge nrst) begin
        if (!nrst) state <= IDLE;
        else state <= next_state;
    end
    
    always @(*) current_state = state;

    // 组合逻辑：带 Pending 机制的仲裁优先级策略
    always @(*) begin
        case (state)
            IDLE: begin
                // 【优先级判定】优先检查是否有挂起的历史遗留问题，或者正好有新数据来
                if (rx_pending || rx_ready) 
                    next_state = RX_PRIO;
                else if (tx_req && !tx_busy) 
                    next_state = TX_PRIO;
                else 
                    next_state = IDLE;
            end
            RX_PRIO:   next_state = WAIT_BUSY;
            TX_PRIO:   next_state = WAIT_BUSY;
            WAIT_BUSY: begin
                // 发送完毕后，必须先回 IDLE 重新进行全局优先级仲裁
                if (!tx_busy && !tx_start) 
                    next_state = IDLE;
                else 
                    next_state = WAIT_BUSY;
            end
            default:   next_state = IDLE;
        endcase
    end

    // 时序逻辑：控制数据线搬运与启动脉冲
    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            tx_start <= 1'b0;
            SBUF_tx  <= 8'd0;
        end else begin
            case (next_state)
                IDLE: begin
                    tx_start <= 1'b0;
                end
                RX_PRIO: begin
                    tx_start <= 1'b1;
                    // 如果是挂起的数据，就发挂起的；如果是新鲜的数据，就发新鲜的
                    SBUF_tx  <= rx_pending ? rx_pending_data : SBUF_rx; 
                end
                TX_PRIO: begin
                    tx_start <= 1'b1;
                    SBUF_tx  <= tx_data_ext; 
                end
                WAIT_BUSY: begin
                    tx_start <= 1'b0; 
                end
            endcase
        end
    end
endmodule