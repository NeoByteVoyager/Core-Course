module uart_system_top(
    input wire clk,                 // 系统时钟 50MHz
    input wire nrst,                // 外部复位，低电平有效
    input wire rx,                  // UART 串行输入线
    input wire tx_req,              // 外部发送请求
    input wire [7:0] tx_data_ext,   // 外部请求发送的单字节数据
    output wire tx,                 // UART 串行输出线
    output wire rx_ready,           // 接收就绪指示
    output wire tx_busy,            // 发送忙状态指示
    output wire [1:0] arb_state     // 仲裁状态输出 (便于调试)
);

    wire [7:0] SBUF_rx;
    wire [7:0] SBUF_tx;
    wire tx_start;

    // 1. 实例化步骤三设计的串口接收模块
    Uart_rx u_rx (
        .clk(clk),
        .nrst(nrst),
        .rx(rx),
        .SBUF_rx(SBUF_rx),
        .rx_ready(rx_ready)
    );

    // 2. 实例化步骤四要求的优先级仲裁器
    Arbitrator u_arb (
        .clk(clk),
        .nrst(nrst),
        .rx_ready(rx_ready),
        .SBUF_rx(SBUF_rx),
        .tx_req(tx_req),
        .tx_data_ext(tx_data_ext),
        .tx_busy(tx_busy),
        .tx_start(tx_start),
        .SBUF_tx(SBUF_tx),
        .current_state(arb_state)
    );

    // 3. 实例化配套的串口发送模块
    Uart_tx u_tx (
        .clk(clk),
        .nrst(nrst),
        .tx_start(tx_start),
        .tx_data(SBUF_tx),
        .tx(tx),
        .tx_busy(tx_busy)
    );

endmodule
