module Uart_tx(
    input wire clk,             // 系统时钟 50MHz
    input wire nrst,            // 外部复位，低电平有效
    input wire tx_start,        // 发送启动脉冲信号 (高电平有效，保持1周期)
    input wire [7:0] tx_data,   // 准备发送的单字节并行数据
    output reg tx,              // UART 串行发送线
    output reg tx_busy          // 发送忙状态指示 (高电平表示正在发送)
);

    parameter BPS_CNT = 16'd434; // 115200波特率计数

    reg [15:0] baud_cnt;
    reg [3:0] bit_cnt;
    reg [7:0] tx_data_reg;
    reg tx_en;

    // 发送使能与忙状态控制
    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            tx_en <= 1'b0;
            tx_busy <= 1'b0;
            tx_data_reg <= 8'd0;
        end else if (tx_start && !tx_busy) begin
            tx_en <= 1'b1;
            tx_busy <= 1'b1;
            tx_data_reg <= tx_data; // 锁存数据
        end else if (bit_cnt == 4'd10) begin // 1位起始+8位数据+1位停止 = 10位传输完毕
            tx_en <= 1'b0;
            tx_busy <= 1'b0;
        end
    end

    // 波特率计数器
    always @(posedge clk or negedge nrst) begin
        if (!nrst) baud_cnt <= 16'd0;
        else if (tx_en) begin
            if (baud_cnt == BPS_CNT - 1) baud_cnt <= 16'd0;
            else baud_cnt <= baud_cnt + 1'b1;
        end else baud_cnt <= 16'd0;
    end

    // 发送位计数器
    always @(posedge clk or negedge nrst) begin
        if (!nrst) bit_cnt <= 4'd0;
        else if (tx_en) begin
            if (baud_cnt == BPS_CNT - 1) bit_cnt <= bit_cnt + 1'b1;
        end else bit_cnt <= 4'd0;
    end

    // 串行输出状态机逻辑 (并转串)
    always @(posedge clk or negedge nrst) begin
        if (!nrst) tx <= 1'b1;
        else if (tx_en) begin
            case (bit_cnt)
                4'd0: tx <= 1'b0; // 起始位 (拉低)
                4'd1: tx <= tx_data_reg[0]; // LSB 低位在前
                4'd2: tx <= tx_data_reg[1];
                4'd3: tx <= tx_data_reg[2];
                4'd4: tx <= tx_data_reg[3];
                4'd5: tx <= tx_data_reg[4];
                4'd6: tx <= tx_data_reg[5];
                4'd7: tx <= tx_data_reg[6];
                4'd8: tx <= tx_data_reg[7];
                4'd9: tx <= 1'b1; // 停止位 (拉高)
                default: tx <= 1'b1;
            endcase
        end else tx <= 1'b1;
    end
endmodule
