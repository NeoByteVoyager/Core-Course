`timescale 1ns / 1ps 

module Uart_rx_tb();

    reg clk;
    reg nrst;
    reg rx;
    wire [7:0] SBUF_rx;
    wire rx_ready;

    // 实例化接收模块
    Uart_rx dut (
        .clk(clk),
        .nrst(nrst),
        .rx(rx),
        .SBUF_rx(SBUF_rx),
        .rx_ready(rx_ready)
    );

    // 产生 50MHz 时钟 (每 10ns 翻转，周期 20ns)
    initial clk = 0;
    always #10 clk = ~clk;

    // 定义一个任务 (Task)，用来模拟串行外设发送单字节数据
    task send_byte;
        input [7:0] data;
        integer i;
        begin
            // 1. 发送起始位 (拉低)
            rx = 0;
            #(434 * 20); // 延时 434 个时钟周期

            // 2. 发送 8 位数据 (串口低位在前 LSB First)
            for (i = 0; i < 8; i = i + 1) begin
                rx = data[i];
                #(434 * 20);
            end

            // 3. 发送停止位 (拉高)
            rx = 1;
            #(434 * 20);
        end
    endtask

    // 仿真激励全流程
    initial begin
        // 初始状态
        nrst = 0;
        rx = 1; // 串口空闲必须是高电平
        #100;
        nrst = 1; // 松开复位
        #500;

        // 1. 发送测试数据 0x55
        send_byte(8'h55);
        #(434 * 20 * 5); // 停顿一会儿

        // 2. 发送测试数据 0xAA
        send_byte(8'hAA);
        #(434 * 20 * 5);

        // 3. 发送测试数据 0xFF
        send_byte(8'hFF);
        #(434 * 20 * 5);

        $stop; // 结束仿真
    end

endmodule
