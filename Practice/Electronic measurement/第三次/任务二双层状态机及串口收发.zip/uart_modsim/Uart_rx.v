module Uart_rx(
    input wire clk,             // 系统时钟 50MHz
    input wire nrst,            // 外部复位，低电平有效
    input wire rx,              // UART 串行接收线
    output reg [7:0] SBUF_rx,   // 8位单字节接收缓冲区
    output reg rx_ready         // 数据接收完成就绪脉冲 (高有效，持续1个时钟周期)
);

    // 参数定义：计算波特率 115200 对应的时钟周期数
    // 50,000,000 / 115200 ≈ 434
    parameter BPS_CNT  = 16'd434; 
    parameter BPS_HALF = 16'd217; // 中间采样点

    // ---------------------------------------------------------
    // 1. 消除亚稳态与起始位下降沿检测
    // ---------------------------------------------------------
    reg rx_reg1, rx_reg2, rx_reg3;
    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            rx_reg1 <= 1'b1; 
            rx_reg2 <= 1'b1; 
            rx_reg3 <= 1'b1; // 空闲时rx为高电平
        end else begin
            rx_reg1 <= rx;       // 第一拍
            rx_reg2 <= rx_reg1;  // 第二拍 (稳定数据)
            rx_reg3 <= rx_reg2;  // 第三拍 (用于边沿对比)
        end
    end
    
    // 当上一拍是高(1)，当前拍是低(0)时，说明捕捉到了起始位的下降沿
    wire rx_fall = rx_reg3 & ~rx_reg2; 

    // ---------------------------------------------------------
    // 2. 接收状态标志位
    // ---------------------------------------------------------
    reg rx_en; // 接收使能标志，1表示正在接收数据
    always @(posedge clk or negedge nrst) begin
        if (!nrst) 
            rx_en <= 1'b0;
        else if (rx_fall) 
            rx_en <= 1'b1;     // 捕捉到下降沿，开启接收
        else if (rx_ready) 
            rx_en <= 1'b0;     // 接收完一个字节后，关闭接收
    end

    // ---------------------------------------------------------
    // 3. 波特率计数器 (数到 434)
    // ---------------------------------------------------------
    reg [15:0] baud_cnt;
    always @(posedge clk or negedge nrst) begin
        if (!nrst) 
            baud_cnt <= 16'd0;
        else if (rx_en) begin
            if (baud_cnt == BPS_CNT - 1) 
                baud_cnt <= 16'd0; // 数满清零
            else 
                baud_cnt <= baud_cnt + 1'b1;
        end else 
            baud_cnt <= 16'd0;
    end

    // ---------------------------------------------------------
    // 4. 位计数器与数据中心采样 (核心逻辑)
    // ---------------------------------------------------------
    reg [3:0] bit_cnt; // 记录收到了第几位 (0-9)
    reg [7:0] rx_data; // 内部临时拼装数据的寄存器

    always @(posedge clk or negedge nrst) begin
        if (!nrst) begin
            bit_cnt <= 4'd0;
            rx_data <= 8'd0;
            rx_ready <= 1'b0;
            SBUF_rx <= 8'd0;
        end else if (rx_en) begin
            // 在码元中心点 (BPS_HALF) 进行采样，此时数据最稳定！
            if (baud_cnt == BPS_HALF) begin 
                case (bit_cnt)
                    4'd0: bit_cnt <= bit_cnt + 1'b1; // 起始位，跳过不存
                    4'd1: begin rx_data[0] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd2: begin rx_data[1] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd3: begin rx_data[2] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd4: begin rx_data[3] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd5: begin rx_data[4] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd6: begin rx_data[5] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd7: begin rx_data[6] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd8: begin rx_data[7] <= rx_reg2; bit_cnt <= bit_cnt + 1'b1; end
                    4'd9: begin // 停止位阶段
                        bit_cnt <= 4'd0;     // 计数器复位
                        rx_ready <= 1'b1;    // 脉冲通知：数据好了！
                        SBUF_rx <= rx_data;  // 把拼装好的数据放进大巴车(缓冲区)
                    end
                    default: bit_cnt <= 4'd0;
                endcase
            end else begin
                rx_ready <= 1'b0; // 保证 rx_ready 只有一个时钟周期的宽度
            end
        end else begin
            bit_cnt <= 4'd0;
            rx_ready <= 1'b0;
        end
    end

endmodule
