// 实验步骤2：适配两种模式的WS2812彩灯控制 + 独立按键调节亮度
// mode=0: LED模式（单灯亮灭，仅绿色）
// mode=1: 数码管模式（单灯彩色，支持绿/红/蓝）
module LED(
    input               clk,         // 开发板50MHz时钟 (PIN_E1)
    input               rst_n,       // 低电平复位按键
    input               key_add,     // 新增：亮度增加按键（假设低电平有效）
    output              led_out      // WS2812彩灯数据输出
);

//==================== 可配置参数（一键切换模式） ====================
// 0 = LED模式（单灯流水，绿色）
// 1 = 数码管模式（彩色流水，绿/红/蓝）
parameter           WORK_MODE = 1;  
wire                mode      = WORK_MODE;

//==================== 内部信号定义 ====================
reg  [7:0]          led_data_in10;  // 两种模式共用的低8位数据
reg  [7:0]          led_data_in32;  // mode=1时使用的高8位数据

//==================== 1. 亮度控制与按键消抖逻辑 ====================
// 说明：机械按键按下时会有几毫秒的抖动，使用慢速采样法过滤抖动
reg [21:0] key_cnt;          // 慢速采样计数器
reg        key_prev;         // 保存上一次采样的按键状态
reg [3:0]  key_brightness;   // 当前亮度寄存器 (0~15)

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        key_cnt <= 22'd0;
        key_prev <= 1'b1;         // 默认按键未按下（高电平）
        key_brightness <= 4'd5;   // 复位后默认亮度为 5
    end else begin
        key_cnt <= key_cnt + 1'b1;
        // 50MHz时钟下，2^22次计数约等于 83.8ms，完美避开机械抖动期
        if(key_cnt == 22'd0) begin 
            key_prev <= key_add;  // 记录此刻的按键状态
            
            // 下降沿检测：如果上次是1（没按），这次是0（按下了）
            if(key_prev == 1'b1 && key_add == 1'b0) begin
                key_brightness <= key_brightness + 1'b1; // 亮度+1，满15自动溢出回0
            end
        end
    end
end

//==================== 2. 流水灯速度控制 ====================
// 分频计数器（50MHz时钟，12,500,000次约0.25秒触发一次）
reg [23:0] cnt;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        cnt <= 24'd0;
    else if(cnt == 24'd12500000)
        cnt <= 24'd0; // 优化：到达计数值后清零，保证周期准确
    else
        cnt <= cnt + 1'b1;
end

//==================== 3. mode=0：LED模式（单灯绿色流水） ====================
reg [7:0] led_mode0;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        led_mode0 <= 8'b00000001;  // 初始点亮灯0
    else if(cnt == 24'd12500000)
        led_mode0 <= {led_mode0[6:0], led_mode0[7]}; // 循环左移
end

//==================== 4. mode=1：数码管模式（彩色流水） ====================
reg [2:0] led_idx;   // 当前点亮的灯号（0~7）
reg [1:0] color_idx; // 当前使用的颜色（1=绿, 2=红, 3=蓝）
reg [7:0] led_mode1_32, led_mode1_10;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        led_idx <= 3'd0;
        color_idx <= 2'd1; 
        led_mode1_32 <= 8'd0;
        led_mode1_10 <= 8'd0;
    end else if(cnt == 24'd12500000) begin
        // 灯号与颜色循环逻辑
        if(led_idx == 3'd7) begin
            led_idx <= 3'd0;
            color_idx <= color_idx + 1'b1;
            if(color_idx == 2'd3) color_idx <= 2'd1; // 跳过灭(0)，只循环绿红蓝
        end else begin
            led_idx <= led_idx + 1'b1;
        end

        // 根据灯号设置对应数据位
        case(led_idx)
            3'd0: begin led_mode1_10 <= {6'd0, color_idx};        led_mode1_32 <= 8'd0; end
            3'd1: begin led_mode1_10 <= {2'd0, color_idx, 4'd0};  led_mode1_32 <= 8'd0; end
            3'd2: begin led_mode1_32 <= {6'd0, color_idx};        led_mode1_10 <= 8'd0; end
            3'd3: begin led_mode1_32 <= {2'd0, color_idx, 4'd0};  led_mode1_10 <= 8'd0; end
            3'd4: begin led_mode1_10 <= {4'd0, color_idx, 2'd0};  led_mode1_32 <= 8'd0; end
            3'd5: begin led_mode1_10 <= {color_idx, 6'd0};        led_mode1_32 <= 8'd0; end
            3'd6: begin led_mode1_32 <= {4'd0, color_idx, 2'd0};  led_mode1_10 <= 8'd0; end
            3'd7: begin led_mode1_32 <= {color_idx, 6'd0};        led_mode1_10 <= 8'd0; end
        endcase
    end
end

//==================== 模式选择与灰盒模块连接 ====================
always @(*) begin
    if(WORK_MODE == 0) begin
        led_data_in10 = led_mode0;
        led_data_in32 = 8'd0;
    end else begin
        led_data_in10 = led_mode1_10;
        led_data_in32 = led_mode1_32;
    end
end

// 调用WS2812灰盒模块
ws2812 u_ws2812(
    .clk            (clk),
    .rst_n          (rst_n),
    .led_data_in32  (led_data_in32),
    .led_data_in10  (led_data_in10),
    .mode           (mode),
    .led_brightness (key_brightness), // 连到动态按键调节的亮度寄存器
    .led_out        (led_out)
);

endmodule