// UART 发送模块（按键触发版）
// 系统时钟 50MHz，波特率修改为 230400 (与步骤三测量结果一致)
module uart_tx(
    input           clk,        // 系统时钟 50MHz
    input           rst_n,      // 低电平复位
    input           key,        // 按键输入（低电平按下）
    output reg      tx_dout,    // 串行输出
    output reg      tx_busy_flag// 忙标志
);

// 时钟与波特率参数
parameter   CLK_FREQ    = 50000000;
parameter   BAUD_RATE   = 115200; // [修改点 1] 波特率改为 230400
parameter   BAUD_CNT_MAX = CLK_FREQ / BAUD_RATE; // 自动计算为 217

// 固定发送数据
parameter   FIX_DATA    = 8'h1E;  // [修改点 2] 数据改为步骤三测出的 0x1E

// 内部寄存器
reg [12:0]  baud_cnt;
reg         baud_clk_en;
reg [3:0]   tx_bit_cnt;
reg [7:0]   tx_data_reg;
reg         tx_en;          // 内部发送使能
reg         key_sync0;
reg         key_sync1;
reg         key_pedge;

// ===================== 按键同步 + 下降沿检测 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        key_sync0 <= 1'b1;
        key_sync1 <= 1'b1;
    end else begin
        key_sync0 <= key;
        key_sync1 <= key_sync0;
    end
end

// 按键按下（下降沿）产生一次发送使能脉冲
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        key_pedge <= 1'b0;
    else
        key_pedge <= (~key_sync0) & key_sync1;
end

// ===================== 发送使能 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_en <= 1'b0;
    else
        tx_en <= key_pedge && (!tx_busy_flag);
end

// ===================== 波特率计数器 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        baud_cnt <= 13'd0;
    else if(tx_busy_flag) begin
        if(baud_cnt == BAUD_CNT_MAX - 1'd1)
            baud_cnt <= 13'd0;
        else
            baud_cnt <= baud_cnt + 1'd1;
    end
    else
        baud_cnt <= 13'd0;
end

// 波特率时钟使能脉冲
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        baud_clk_en <= 1'b0;
    else
        baud_clk_en <= (baud_cnt == 13'd1); // 注意：这里用 1 或 BAUD_CNT_MAX-1 都可以，只要每个周期产生一次脉冲即可
end

// ===================== 发送位计数器 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_bit_cnt <= 4'd0;
    else if(tx_busy_flag && baud_clk_en) begin
        if(tx_bit_cnt == 4'd9)
            tx_bit_cnt <= 4'd0;
        else
            tx_bit_cnt <= tx_bit_cnt + 1'd1;
    end
    else if(!tx_busy_flag)
        tx_bit_cnt <= 4'd0;
end

// ===================== 忙标志控制 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_busy_flag <= 1'b0;
    else if(tx_en && !tx_busy_flag)
        tx_busy_flag <= 1'b1;
    else if(tx_bit_cnt == 4'd9 && baud_clk_en)
        tx_busy_flag <= 1'b0;
end

// ===================== 数据锁存 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_data_reg <= 8'd0;
    else if(tx_en && !tx_busy_flag)
        tx_data_reg <= FIX_DATA; // 锁存 0x1E
end

// ===================== 串行输出 =====================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        tx_dout <= 1'b1;
    else if(baud_clk_en) begin
        case(tx_bit_cnt)
            4'd0: tx_dout <= 1'b0;          // 起始位
            4'd1: tx_dout <= tx_data_reg[0];
            4'd2: tx_dout <= tx_data_reg[1];
            4'd3: tx_dout <= tx_data_reg[2];
            4'd4: tx_dout <= tx_data_reg[3];
            4'd5: tx_dout <= tx_data_reg[4];
            4'd6: tx_dout <= tx_data_reg[5];
            4'd7: tx_dout <= tx_data_reg[6];
            4'd8: tx_dout <= tx_data_reg[7];
            4'd9: tx_dout <= 1'b1;          // 停止位
            default:tx_dout <= 1'b1;
        endcase
    end
end

endmodule