/* Quartus Prime Version 24.1std.0 Build 1077 03/04/2025 SC Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE15F17) Path("D:/Quartur/Code/wenjian/") File("exp_uart.sof") MfrSpec(OpMask(1));
	P ActionCode(Ign)
		Device PartName(EP4CE15F17) MfrSpec(OpMask(0) FullPath("D:/Quartur/Code/uart_tx/output_files/uart_tx.sof"));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
