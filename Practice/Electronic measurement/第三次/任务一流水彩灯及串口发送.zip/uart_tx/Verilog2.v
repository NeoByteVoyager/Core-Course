module uart_tx_top(
    input  wire clk,      // 开发板 50MHz 晶振输入
    input  wire rst_n,    // 开发板 nrst 复位按键
    input  wire key_k1,   // 开发板 K1 按键 (发送触发)
    output wire tx_dout   // 开发板 串口 Tx 输出引脚
);

    // ==========================================
    // 1. 按键下降沿检测 (消除长按导致的连续触发)
    // ==========================================
    reg key_d0, key_d1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_d0 <= 1'b1;
            key_d1 <= 1'b1;
        end else begin
            key_d0 <= key_k1;
            key_d1 <= key_d0;
        end
    end
    
    // 当检测到从高电平跳变为低电平时，产生一个时钟周期的高脉冲
    wire tx_en_pulse = (~key_d0) & key_d1; 

    // ==========================================
    // 2. 例化底层 UART 发送模块
    // ==========================================
    uart_tx #(
        .BPS_CNT(217) // 对应 230400 波特率
    ) u_uart_tx (
        .clk         (clk),
        .rst_n       (rst_n),
        .tx_en       (tx_en_pulse),
        .tx_data     (8'h1E),    // 绑定步骤三测得的固定数据 0x1E
        .tx_dout     (tx_dout),
        .tx_busy_flag()          // 顶层不需要使用该标志，悬空即可
    );

endmodule