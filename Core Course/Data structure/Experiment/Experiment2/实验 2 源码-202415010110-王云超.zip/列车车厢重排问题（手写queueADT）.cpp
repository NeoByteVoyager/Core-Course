#include<bits/stdc++.h>
using namespace std;

template <typename T>
class MyQueue {
private:
    // ����ֻ��Ҫ��������
    struct Node {
        T val;
        Node* next;
        Node(T v) : val(v), next(nullptr) {}
    };

    Node* head; // ��ͷָ��
    Node* tail; // ��βָ��
    int count;  // ��¼Ԫ�ظ���

public:
    MyQueue() : head(nullptr), tail(nullptr), count(0) {}

    // �������캯�� 
    MyQueue(const MyQueue& other) : head(nullptr), tail(nullptr), count(0) {
        Node* curr = other.head;
        while (curr != nullptr) {
            push(curr->val);
            curr = curr->next;
        }
    }

    // ��ֵ���������
    MyQueue& operator=(const MyQueue& other) {
        if (this == &other) return *this;
        while (!empty()) pop(); 
        Node* curr = other.head;
        while (curr != nullptr) {
            push(curr->val);
            curr = curr->next;
        }
        return *this;
    }

    ~MyQueue() {
        while (!empty()) pop();
    }

    bool empty() const {
        return count == 0;
    }

    // ��ȡ��ͷԪ��
    T front() const {
        return head->val;
    }

    // ��ȡ��βԪ��
    T back() const {
        return tail->val;
    }

    // ��ӣ����ڵ���������β��
    void push(T x) {
        Node* newNode = new Node(x);
        if (empty()) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
        count++;
    }

    // ���ӣ��ӵ���������ͷ��ɾ��
    void pop() {
        if (empty()) return;
        Node* temp = head;
        head = head->next;
        if (head == nullptr) {
            tail = nullptr; // ���ɾ���ˣ�βָ��ҲҪ�ÿ�
        }
        delete temp;
        count--;
    }
};


vector<int> seq;
vector<MyQueue<int>> qi;
int res = 0, cur = 1; 

void add(int x){
    int idx = -1, max_val = -1; 
    for(int i = 0; i < qi.size(); i++){
        if(!qi[i].empty() && qi[i].back() < x) {
            if(qi[i].back() > max_val){
                idx = i;
                max_val = qi[i].back();
            }
        }
        else if(qi[i].empty() && max_val == -1) idx = i;
    }
    
    if(idx == -1){ 
        res++; 
        MyQueue<int> q; 
        qi.push_back(q);
        qi[qi.size()-1].push(x); 
    }
    else{
         qi[idx].push(x); 
    }
    
    while(true){
        int flag = false;
        for(int i = 0; i < qi.size(); i++){
            if(!qi[i].empty() && qi[i].front() == cur){
                qi[i].pop();
                cur++;
                flag = true;
            }
        }
        if(!flag) break;
    }
}

int main(){
    int x; 
    while(cin >> x){
        seq.push_back(x);
    }
    for(int i = seq.size()-1; i >= 0; i--){
        add(seq[i]);
    }
    cout << res;
    return 0;
}
