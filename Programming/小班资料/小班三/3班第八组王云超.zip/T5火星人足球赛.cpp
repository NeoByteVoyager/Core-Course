#include <bits/stdc++.h>
using namespace std;

struct RedEvent {
    string team;
    int player;
    int time;
    int type;  // 0 = ����, 1 = �Ͷ�
};

int main() {
    string home, away;
    cin >> home >> away;

    int n;
    cin >> n;

    map<int,int> yellowH, yellowA;  // ÿ����Ա������
    map<int,int> redH, redA;        // �Ƿ��ѷ���

    vector<RedEvent> ans;

    while(n--) {
        int t, num;
        char team, card;
        cin >> t >> team >> num >> card;

        if(team == 'h') {
            // ����
            if(redH[num]) continue;
            if(card == 'r') {
                redH[num] = 1;
                ans.push_back({home, num, t, 0});
            } else {
                // ����
                if(yellowH[num] == 1) {
                    redH[num] = 1;
                    ans.push_back({home, num, t, 0});
                } else {
                    yellowH[num] = 1;
                }
            }
        } else {
            // �Ͷ�
            if(redA[num]) continue;
            if(card == 'r') {
                redA[num] = 1;
                ans.push_back({away, num, t, 1});
            } else {
                if(yellowA[num] == 1) {
                    redA[num] = 1;
                    ans.push_back({away, num, t, 1});
                } else {
                    yellowA[num] = 1;
                }
            }
        }
    }

    if(ans.empty()) {
        cout << "No Red Card";
        return 0;
    }

    sort(ans.begin(), ans.end(), [](auto &a, auto &b){
        if(a.time != b.time) return a.time < b.time;
        if(a.type != b.type) return a.type < b.type;
        return a.player > b.player; // ��Ŵ����ǰ��
    });

    for(auto &e : ans) {
        cout << e.team << " " << e.player << " " << e.time << "\n";
    }

    return 0;
}

