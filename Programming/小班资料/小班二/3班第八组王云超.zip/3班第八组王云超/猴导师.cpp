#include<iostream>
#include<vector>
using namespace std;

int main(){
    int n, m;
    cin >> n >> m;
    vector<int> a(n+1); // �������飬1-indexed
    vector<vector<int>> t(n+1); // ��ͻ��ϵ��

    for(int i = 1; i <= n; i++) cin >> a[i]; // ���뼼��

    while(m--){
        int x, y;
        cin >> x >> y;
        t[x].push_back(y);
        t[y].push_back(x); // ˫���ͻ
    }

    vector<int> cnt(n+1, 0); // �ɳ�Ϊ��ʦ������

    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            if(j == i) continue;
            if(a[i] > a[j]){
                bool ok = true;
                for(int k : t[i]){
                    if(k == j){ // �г�ͻ
                        ok = false;
                        break;
                    }
                }
                if(ok) cnt[i]++;
            }
        }
        cout << cnt[i] << " ";
    }

    return 0;
}

