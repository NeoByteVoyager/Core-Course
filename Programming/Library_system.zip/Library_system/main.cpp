#include <iostream>
#include "Book.h"
#include "LibrarySystem.h" 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	LibrarySystem l;
	l.run(); 
	
	return 0;
}
