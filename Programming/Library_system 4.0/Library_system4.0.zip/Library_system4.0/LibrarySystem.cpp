#include "LibrarySystem.h"

// ���캯��������ʱ�Զ���ȡ���� 
LibrarySystem::LibrarySystem() {
    currentUser = NULL;
    loadData(); // �ȳ��Դ��ļ���������

    if (bookList.empty()) addTestBook();
    if (userList.empty()) initUsers();
}

// �����������˳�ʱ�Զ����� 
LibrarySystem::~LibrarySystem() {
    saveData(); 
    for(int i = 0; i < userList.size(); i++) {
        delete userList[i];
    }
}

// ��������
void LibrarySystem::saveData() {
    // 1. �����鼮
    ofstream bookFile("books.txt");
    if (bookFile.is_open()) {
        for (int i = 0; i < bookList.size(); i++) {
            bookFile << bookList[i].getTitle() << " "
                     << bookList[i].getISBN() << " "
                     << bookList[i].getAuthor() << " "
                     << bookList[i].getPublisher() << " "
                     << bookList[i].getPublishDate() << " "
                     << bookList[i].getPrice() << " "
                     << bookList[i].getBorrowCount() << endl;
        }
        bookFile.close();
    }

    // 2. �����û�
    ofstream userFile("users.txt");
    if (userFile.is_open()) {
        for (int i = 0; i < userList.size(); i++) {
            userFile << userList[i]->getRole() << " "
                     << userList[i]->getAccount() << " "
                     << userList[i]->getPassword() << endl; 
        }
        userFile.close();
    }
}

// ��ȡ����
void LibrarySystem::loadData() {
    // ��ȡ�鼮
    ifstream bookFile("books.txt");
    if (bookFile.is_open()) {
        string t, i, a, p, d;
        double pr;
        int bc;
        while (bookFile >> t >> i >> a >> p >> d >> pr >> bc) {
            Book b(t, i, a, p, d, pr);
            b.setBorrowCount(bc); 
            bookList.push_back(b);
        }
        bookFile.close();
    }

    // ��ȡ�û�
    ifstream userFile("users.txt");
    if (userFile.is_open()) {
        int r;
        string acc, pwd;
        while (userFile >> r >> acc >> pwd) {
            if (r == 1) userList.push_back(new Admin(acc, pwd));
            else if (r == 2) userList.push_back(new Reader(acc, pwd));
        }
        userFile.close();
    }
}

// ���Ӳ����鼮 
void LibrarySystem::addTestBook() {
    bookList.push_back(Book("C++�������", "978-7-100", "̷��ǿ", "�廪��ѧ������", "2019-01", 59.0));
    bookList.push_back(Book("��������", "978-7-200", "JK����", "������ѧ������", "2000-09", 68.5));
    bookList.push_back(Book("Java���˼��", "978-7-300", "Bruce_Eckel", "��е��ҵ������", "2007-06", 108.0));
}

// չʾ�����鼮 
void LibrarySystem::showAllBooks() {
    cout << "\n=== �ݲ��鼮�б� (" << bookList.size() << "��) ===" << endl;
    for(int i = 0; i < bookList.size(); i++) {
        bookList[i].showInfo();
    }
}

// ��ʼ���û�
void LibrarySystem::initUsers() {
    userList.push_back(new Admin("admin", "123456")); 
    userList.push_back(new Reader("tom", "123456"));  
}

// ��¼����
bool LibrarySystem::login() {
    string acc, pwd;
    
  
    system("cls"); 

    
    cout << endl;
    cout << "    +----------------------------------------+" << endl;
    cout << "    |                                        |" << endl;
    cout << "    |           H��ѧͼ�����ϵͳ            |" << endl;
    cout << "    |                �û���¼                |" << endl;
    cout << "    |                                        |" << endl;
    cout << "    +----------------------------------------+" << endl;
    cout << endl;

 
    cout << "      ��  �� : "; 
    cin >> acc;
    
    cout << "      ��  �� : ";
    cin >> pwd;
    
    cout << endl;
    cout << "    ------------------------------------------" << endl;


    cin.ignore(1024, '\n');

    for(int i = 0; i < userList.size(); i++) {
        if (userList[i]->getAccount() == acc) {
            if (userList[i]->checkPassword(pwd)) {
                currentUser = userList[i];
                
                cout << endl;
                cout << "      [ ϵͳ��ʾ: ��¼�ɹ� ]" << endl;
                cout << "      ��ӭ������ " << acc << "��" << endl;
                cout << endl;
                
                system("pause");
                return true;
            } else {
                cout << endl;
                cout << "      [ ����: ���벻��ȷ ]" << endl;
                cout << "      ��������ԡ�" << endl;
                cout << endl;
                
                system("pause");
                return false;
            }
        }
    }

    // �˺Ų�����
    cout << endl;
    cout << "      [ ����: �˺Ų����� ]" << endl;
    cout << "      ����ע��������롣" << endl;
    cout << endl;
    
    system("pause");
    return false;
}
// === �˵�ϵͳ ===

void LibrarySystem::adminMenu() {
    int choice;
    do {
        system("cls");
        Menu::showAdmin();
        if (!(cin >> choice)) { cin.clear(); cin.ignore(1024, '\n'); choice = -1; }
        else cin.ignore(1024, '\n');

        switch(choice) {
            case 1: adminUserMenu(); break;
            case 2: adminBookMenu(); break;
            case 0: cout << "����ע��..." << endl; break;
            default: cout << "��Ч���롣" << endl; system("pause");
        }
    } while (choice != 0);
}

// ����Ա-�û�����
void LibrarySystem::adminUserMenu() {
    // ȷ���ǹ���Ա
    if (currentUser->getRole() != 1) return;
    Admin* admin = (Admin*)currentUser; // ǿתָ��

    int choice;
    do {
        system("cls");
        Menu::adminUserMenu();
        if (!(cin >> choice)) { cin.clear(); cin.ignore(1024, '\n'); choice = -1; }
        else cin.ignore(1024, '\n');
        
        switch(choice) {
            case 1: 
                admin->addReader(userList); // ���� Admin ��ķ���
                saveData(); 
                break;
            case 2: 
                admin->deleteReader(userList); 
                saveData(); 
                break;
            case 3: 
                admin->viewAllReaders(userList); 
                break;
            case 4: 
                admin->resetReaderPassword(userList); 
                saveData(); 
                break;
            case 0: break;
            default: cout << "������Ч" << endl; system("pause");
        }
    } while (choice != 0);
}

// ����Ա-�鼮����
void LibrarySystem::adminBookMenu() {
    // ȷ���ǹ���Ա
    if (currentUser->getRole() != 1) return;
    Admin* admin = (Admin*)currentUser; // ǿתָ��

    int choice;
    do {
        system("cls");
        Menu::adminBookMenu();
        if (!(cin >> choice)) { cin.clear(); cin.ignore(1024, '\n'); choice = -1; }
        else cin.ignore(1024, '\n');
        
        switch(choice) {
            case 1:
                admin->addBook(bookList); // ���� Admin ��ķ���
                saveData();
                break;
            case 2:
                admin->deleteBook(bookList);
                saveData();
                break;
            case 3:
                admin->modifyBook(bookList);
                saveData();
                break;
            case 4:
                showAllBooks(); 
                system("pause");
                break;
            case 0: break;
            default: cout << "������Ч" << endl; system("pause");
        }
    } while (choice != 0);
}

// ���߲˵� 
void LibrarySystem::readerMenu() {
    // ȷ���Ƕ���
    if (currentUser->getRole() != 2) return;
    Reader* reader = (Reader*)currentUser; // ǿתָ��
    system("cls");
	RankList::recommendBook(bookList); 
        cout << endl;
        system("pause");
        system("cls");
    int choice;
    do {
        system("cls");
        
        Menu::showReader();
        if (!(cin >> choice)) { cin.clear(); cin.ignore(1024, '\n'); choice = -1; }
        else cin.ignore(1024, '\n');

        switch(choice) {
            case 1:
                // === �����Ӳ˵� (ֱ�ӵ��� LibrarySystem �ĺ���) ===
                {
                    int searchType;
                    system("cls");
                    Menu::readerSerachMenu();
                    if (!(cin >> searchType)) { cin.clear(); cin.ignore(1024, '\n'); }
                    else cin.ignore(1024, '\n');

                    if (searchType == 1) searchByTitle();
                    else if (searchType == 2) searchByISBN();
                    else if (searchType == 3) searchByAuthor();
                }
                break;
            case 2:
                // === �軹�Ӳ˵� (���� Reader ��ķ���) ===
                {
                    int type;
                    system("cls");
                    Menu::readerBoReMenu();
                    if (!(cin >> type)) { cin.clear(); cin.ignore(1024, '\n'); }
                    else cin.ignore(1024, '\n');

                    if (type == 1) {
                        reader->borrowBook(bookList); // �����鵥
                        saveData();
                    }
                    else if (type == 2) {
                        reader->returnBook(bookList); // �����鵥
                        saveData();
                    }
                }
                break;
            case 3:
                showRanking(); 
                break;
            case 0: break;
            default: cout << "��Ч���롣" << endl; system("pause");
        }
    } while (choice != 0);
}

// === �������� ===

void LibrarySystem::searchByTitle() {
    string inputTitle;
    cout << "\n=== ���������� ===" << endl;
    cout << "����������: ";
    cin >> inputTitle;

    bool found = false;
    for (int i = 0; i < bookList.size(); i++) {
        if (bookList[i].getTitle() == inputTitle) {
            bookList[i].showInfo();
            found = true;
        }
    }
    if (!found) cout << "δ�ҵ���Ϊ \"" << inputTitle << "\" ���鼮��" << endl;
    cin.ignore(1024, '\n');
    system("pause");
}

void LibrarySystem::searchByISBN() {
    string inputISBN;
    cout << "\n=== ��ISBN���� ===" << endl;
    cout << "������ISBN: ";
    cin >> inputISBN;

    bool found = false;
    for (int i = 0; i < bookList.size(); i++) {
        if (bookList[i].getISBN() == inputISBN) {
            bookList[i].showInfo();
            found = true;
            break;
        }
    }
    if (!found) cout << "δ�ҵ��� ISBN ���鼮��" << endl;
    cin.ignore(1024, '\n');
    system("pause");
}

void LibrarySystem::searchByAuthor() {
    string inputAuthor;
    cout << "\n=== ���������� ===" << endl;
    cout << "������������: ";
    cin >> inputAuthor;

    vector<Book> results;
    for (int i = 0; i < bookList.size(); i++) {
        if (bookList[i].getAuthor() == inputAuthor) {
            results.push_back(bookList[i]);
        }
    }

    if (results.empty()) {
        cout << "δ�ҵ����� \"" << inputAuthor << "\" ���鼮��" << endl;
    } else {
        sort(results.begin(), results.end(), [](const Book& a, const Book& b) {
            return a.getTitle() < b.getTitle();
        });

        cout << "\n�ҵ� " << results.size() << " ���� (�Ѱ���������):" << endl;
        for (int i = 0; i < results.size(); i++) {
            results[i].showInfo();
        }
    }
    cin.ignore(1024, '\n');
    system("pause");
}

// === ���а��� ===
void LibrarySystem::showRanking() {
    int type;
    system("cls");
    Menu::RankingMenu();
    if (!(cin >> type)) { cin.clear(); cin.ignore(1024, '\n'); type = -1; }
    else cin.ignore(1024, '\n');

    if (type == 1) {
        RankList::showHotRanking(bookList);
        system("pause");
    } 
    else if (type == 2) {
        RankList::showNewRanking(bookList);
        system("pause");
    }
    else if (type == 0) return;
    else {
        cout << "��Чѡ��" << endl;
        system("pause");
    }
}

// ϵͳ������� 
void LibrarySystem::run() {
	system("color 3F");
    while (true) { 
        system("cls"); 
        Menu::showMain();

        if (login()) {
            if (currentUser->getRole() == 1) {
                adminMenu(); 
            } else {
                readerMenu(); 
            }
            currentUser = NULL; 
        } else {
            cout << "��¼ʧ�ܣ������ԡ�" << endl;
            system("pause");
        }
    }
}
