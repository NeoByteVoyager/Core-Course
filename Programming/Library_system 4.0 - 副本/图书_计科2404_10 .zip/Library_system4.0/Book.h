#ifndef BOOK_H
#define BOOK_H
#include<iostream>
#include <string>
using namespace std;

class Book {
private:
	string title;
	string isbn;
	string author;
	string publisher;
	string publishDate;//�ṩ�������й��� 
	double price;
	int borrowCount;//�ṩ���Ĵ���ǰʮ���� 
public:
	Book(string t,string i,string author,string p,string date,double pr);
	Book(){}
	
	void showInfo() const;
	
	string  getTitle() const;
	string getISBN() const;
	string getAuthor() const;
	string getPublisher() const;
    string getPublishDate() const;
	double getPrice() const;
	int getBorrowCount() const;
	void setBorrowCount(int count); 
	void addBorrowCount(); 
	void setTitle(string t);
    void setAuthor(string a);
    void setPublisher(string p);
    void setPublishDate(string d);
    void setPrice(double pr);
};

#endif

